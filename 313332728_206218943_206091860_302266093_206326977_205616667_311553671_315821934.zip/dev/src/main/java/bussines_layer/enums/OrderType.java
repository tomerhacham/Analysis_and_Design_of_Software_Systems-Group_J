package bussines_layer.enums;

public enum OrderType
{PeriodicOrder,OutOfStockOrder;}
