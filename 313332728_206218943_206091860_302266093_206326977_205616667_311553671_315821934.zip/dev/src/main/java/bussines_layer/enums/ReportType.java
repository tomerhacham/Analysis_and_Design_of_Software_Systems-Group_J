package bussines_layer.enums;

public enum ReportType
{OutOfStock,InStock,ExpiredDamaged;}
