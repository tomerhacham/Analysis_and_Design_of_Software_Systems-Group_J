package bussines_layer.enums;


public enum supplierType {byOrder , fix_days, selfDelivery}
