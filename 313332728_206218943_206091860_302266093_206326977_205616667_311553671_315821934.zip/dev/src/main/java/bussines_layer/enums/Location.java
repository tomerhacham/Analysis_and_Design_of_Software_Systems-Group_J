package bussines_layer.enums;

public enum Location
{warehouse,store;}
