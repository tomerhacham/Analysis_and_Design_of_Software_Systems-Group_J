package bussines_layer.enums;

public enum discountType
{fix,precentage;}
