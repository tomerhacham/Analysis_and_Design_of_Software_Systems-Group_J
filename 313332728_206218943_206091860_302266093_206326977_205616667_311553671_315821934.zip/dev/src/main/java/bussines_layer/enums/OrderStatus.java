package bussines_layer.enums;

public enum OrderStatus
{received,inProcess , sent}
